import os
import subprocess
import sys

def main():
    try:
        # Crear un entorno virtual si no existe
        if not os.path.exists("venv"):
            print("Creando entorno virtual...")
            subprocess.check_call([sys.executable, "-m", "venv", "venv"])

        # Determinar el script de activación según el sistema operativo
        if os.name == "nt":  # Windows
            python_executable = os.path.join("venv", "Scripts", "python.exe")
        else:  # Sistemas basados en Unix
            python_executable = os.path.join("venv", "bin", "python")

        # Actualizar pip en el entorno virtual
        print("Actualizando pip en el entorno virtual...")
        subprocess.check_call([python_executable, "-m", "pip", "install", "--upgrade", "pip"])

        # Instalar las dependencias desde requirements.txt
        print("Instalando dependencias...")
        # Línea de depuración para verificar la ruta absoluta de requirements.txt
        print(f"Buscando el archivo requirements.txt en: {os.path.abspath('requirements.txt')}")
        
        requirements_path = "requirements.txt"
        if not os.path.exists(requirements_path):
            raise FileNotFoundError(f"No se encontró el archivo {requirements_path}.")
        subprocess.check_call([python_executable, "-m", "pip", "install", "-r", requirements_path])

        # Ejecutar el programa principal (Interfaz.py)
        print("Ejecutando la interfaz...")
        interfaz_path = os.path.abspath(os.path.join("Cliente", "Interfaz.py"))
        print(f"Buscando el archivo Interfaz.py en: {interfaz_path}")
        if not os.path.exists(interfaz_path):
            raise FileNotFoundError(f"No se encontró el archivo {interfaz_path}.")
        subprocess.check_call([python_executable, interfaz_path])

    except subprocess.CalledProcessError as e:
        print(f"Error al ejecutar el comando: {e.cmd}")
        print(f"Código de salida: {e.returncode}")
        print("Asegúrate de que las dependencias sean válidas y que el entorno virtual esté configurado correctamente.")
    except FileNotFoundError as e:
        print(f"Archivo no encontrado: {e}")
    except Exception as e:
        print(f"Error inesperado: {e}")

if __name__ == "__main__":
    main()


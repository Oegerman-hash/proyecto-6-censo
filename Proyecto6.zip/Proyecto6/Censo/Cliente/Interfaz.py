import tkinter as tk
from tkinter import ttk

# Crear ventana principal
ventana1 = tk.Tk()
ventana1.title("Formulario Municipio")

# Crear un marco principal para contener los elementos
frame = ttk.Frame(ventana1, padding="10")
frame.grid(row=0, column=0, sticky="nsew")

# Etiquetas y campos de entrada
campos = [
    "Nombre", "Población Total", "Hombres", "Edad Promedio",
    "Ingreso Promedio", "Temperatura Media", "ID Departamento",
    "ID Municipio (para Modificar/Eliminar)", "Nuevo Nombre (para Modificar)"
]

entries = []
for i, campo in enumerate(campos):
    ttk.Label(frame, text=campo, font=("Arial", 12)).grid(row=i, column=0, sticky="w", padx=5, pady=5)
    entry = ttk.Entry(frame, font=("Arial", 12), width=40)
    entry.grid(row=i, column=1, padx=5, pady=5)
    entries.append(entry)

# Separador
separator = ttk.Separator(frame, orient="horizontal")
separator.grid(row=len(campos), column=0, columnspan=2, sticky="ew", pady=10)

# Botones
button_frame = ttk.Frame(frame, padding="10")
button_frame.grid(row=len(campos) + 1, column=0, columnspan=2)

# Crear botones con colores y fuentes ajustadas
guardar_btn = tk.Button(
    button_frame,
    text="Guardar Municipio",
    font=("Arial", 12, "bold"),
    bg="#4CAF50",  # Verde oscuro
    fg="white",    # Texto blanco
    activebackground="#45A049",  # Color cuando se pasa el cursor
    activeforeground="white",
    width=25,
    height=2
)
guardar_btn.grid(row=0, column=0, padx=10, pady=5)

modificar_btn = tk.Button(
    button_frame,
    text="Modificar Municipio",
    font=("Arial", 12, "bold"),
    bg="#FFC107",  # Amarillo oscuro
    fg="black",    # Texto negro
    activebackground="#FFB300",
    activeforeground="black",
    width=25,
    height=2
)
modificar_btn.grid(row=0, column=1, padx=10, pady=5)

eliminar_btn = tk.Button(
    button_frame,
    text="Eliminar Municipio",
    font=("Arial", 12, "bold"),
    bg="#F44336",  # Rojo oscuro
    fg="white",    # Texto blanco
    activebackground="#E53935",
    activeforeground="white",
    width=25,
    height=2
)
eliminar_btn.grid(row=0, column=2, padx=10, pady=5)

# Ejecutar ventana
ventana1.mainloop()





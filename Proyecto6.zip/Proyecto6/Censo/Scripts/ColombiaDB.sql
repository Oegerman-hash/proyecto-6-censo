-- Creacion y uso de tabla -- 
CREATE DATABASE CensoMunicipal;
USE CensoMunicipal;

-- Tabla departamentos --
CREATE TABLE Departamentos (
    id_departamento INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    poblacion_total INT DEFAULT 0,
    hombres_total INT DEFAULT 0,
    mujeres_total INT DEFAULT 0,
    edad_promedio DECIMAL(5, 2) DEFAULT 0.00,
    ingreso_promedio DECIMAL(10, 2) DEFAULT 0.00,
    temperatura_media DECIMAL(5, 2) DEFAULT 0.00
);

-- Tabla Municipios --
CREATE TABLE Municipios (
    id_municipio INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE,
    poblacion_total INT NOT NULL,
    hombres INT NOT NULL,
    mujeres INT GENERATED ALWAYS AS (poblacion_total - hombres) STORED,
    edad_promedio DECIMAL(5, 2) NOT NULL,
    ingreso_promedio DECIMAL(10, 2) NOT NULL,
    temperatura_media DECIMAL(5, 2) NOT NULL,
    id_departamento INT NOT NULL,
    FOREIGN KEY (id_departamento) REFERENCES Departamentos(id_departamento) ON DELETE CASCADE
);

-- Eliminar tablas (por si acaso) -- 
-- DROP TABLE IF EXISTS Municipios;
-- DROP TABLE IF EXISTS Departamentos;

-- Ingresar los 32 departamentos --
INSERT INTO Departamentos (nombre) VALUES
('Amazonas'), ('Antioquia'), ('Arauca'), ('Atlántico'), ('Bolívar'),
('Boyacá'), ('Caldas'), ('Caquetá'), ('Casanare'), ('Cauca'), ('Cesar'),
('Chocó'), ('Córdoba'), ('Cundinamarca'), ('Guainía'), ('Guajira'),
('Guaviare'), ('Huila'), ('Magdalena'), ('Meta'), ('Nariño'),
('Norte de Santander'), ('Putumayo'), ('Quindío'), ('Risaralda'),
('San Andrés y Providencia'), ('Santander'), ('Sucre'), ('Tolima'),
('Valle del Cauca'), ('Vaupés'), ('Vichada');


-- Disparadores para actualizar al insertar  --
DELIMITER $$

CREATE TRIGGER after_insert_municipio
AFTER INSERT ON Municipios
FOR EACH ROW
BEGIN
    -- Verificar si la población total es mayor a 0 para evitar división por cero
    IF (SELECT poblacion_total FROM Departamentos WHERE id_departamento = NEW.id_departamento) > 0 THEN
        UPDATE Departamentos
        SET 
            poblacion_total = poblacion_total + NEW.poblacion_total,
            hombres_total = hombres_total + NEW.hombres,
            mujeres_total = mujeres_total + NEW.mujeres,
            edad_promedio = ((edad_promedio * poblacion_total) + (NEW.edad_promedio * NEW.poblacion_total)) / (poblacion_total + NEW.poblacion_total),
            ingreso_promedio = ((ingreso_promedio * poblacion_total) + (NEW.ingreso_promedio * NEW.poblacion_total)) / (poblacion_total + NEW.poblacion_total),
            temperatura_media = ((temperatura_media * poblacion_total) + (NEW.temperatura_media * NEW.poblacion_total)) / (poblacion_total + NEW.poblacion_total)
        WHERE id_departamento = NEW.id_departamento;
    ELSE
        -- Si es la primera población registrada, asignar directamente los valores del municipio
        UPDATE Departamentos
        SET 
            poblacion_total = NEW.poblacion_total,
            hombres_total = NEW.hombres,
            mujeres_total = NEW.mujeres,
            edad_promedio = NEW.edad_promedio,
            ingreso_promedio = NEW.ingreso_promedio,
            temperatura_media = NEW.temperatura_media
        WHERE id_departamento = NEW.id_departamento;
    END IF;
END$$

DELIMITER ;
-- Eliminar Trigger (prueba)
-- DROP TRIGGER IF EXISTS after_insert_municipio;

-- Disparador para actualizar al eliminar -- 
DELIMITER $$

CREATE TRIGGER after_delete_municipio
AFTER DELETE ON Municipios
FOR EACH ROW
BEGIN
    -- Verificar si la población restante será mayor a 0 para evitar división por cero
    IF (SELECT poblacion_total - OLD.poblacion_total FROM Departamentos WHERE id_departamento = OLD.id_departamento) > 0 THEN
        UPDATE Departamentos
        SET 
            poblacion_total = poblacion_total - OLD.poblacion_total,
            hombres_total = hombres_total - OLD.hombres,
            mujeres_total = mujeres_total - OLD.mujeres,
            edad_promedio = ((edad_promedio * poblacion_total) - (OLD.edad_promedio * OLD.poblacion_total)) / (poblacion_total - OLD.poblacion_total),
            ingreso_promedio = ((ingreso_promedio * poblacion_total) - (OLD.ingreso_promedio * OLD.poblacion_total)) / (poblacion_total - OLD.poblacion_total),
            temperatura_media = ((temperatura_media * poblacion_total) - (OLD.temperatura_media * OLD.poblacion_total)) / (poblacion_total - OLD.poblacion_total)
        WHERE id_departamento = OLD.id_departamento;
    ELSE
        -- Si es el último municipio del departamento, resetear valores
        UPDATE Departamentos
        SET 
            poblacion_total = 0,
            hombres_total = 0,
            mujeres_total = 0,
            edad_promedio = 0,
            ingreso_promedio = 0,
            temperatura_media = 0
        WHERE id_departamento = OLD.id_departamento;
    END IF;
END$$

DELIMITER ;

-- Actualizar datos de tabla
INSERT INTO Municipios (nombre, poblacion_total, hombres, edad_promedio, ingreso_promedio, temperatura_media, id_departamento)
VALUES ('Bogotá', 8000000, 3800000, 31.2, 1800000, 15.5, 13); 

DELETE FROM Municipios WHERE nombre = 'Bogotá';


-- Ver tablas
SELECT * FROM Municipios;
SELECT * FROM Departamentos;

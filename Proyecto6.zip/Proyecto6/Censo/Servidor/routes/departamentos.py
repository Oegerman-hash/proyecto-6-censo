from flask import Blueprint, jsonify
from db_connection import get_db_connection

departamentos_bp = Blueprint('departamentos', __name__)

# Ruta para obtener los datos consolidados de un departamento
@departamentos_bp.route('/<int:id_departamento>', methods=['GET'])
def obtener_departamento(id_departamento):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Departamentos WHERE id_departamento = %s", (id_departamento,))
    departamento = cursor.fetchone()
    conn.close()

    if departamento:
        return jsonify({
            'id_departamento': departamento[0],
            'nombre': departamento[1],
            'poblacion_total': departamento[2],
            'hombres_total': departamento[3],
            'mujeres_total': departamento[4],
            'edad_promedio': departamento[5],
            'ingreso_promedio': departamento[6],
            'temperatura_media': departamento[7]
        }), 200
    else:
        return jsonify({'error': 'Departamento no encontrado'}), 404

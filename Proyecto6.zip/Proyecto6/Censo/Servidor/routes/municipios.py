from flask import Blueprint, request, jsonify
from db_connection import get_db_connection

municipios_bp = Blueprint('municipios', __name__)

# Ruta para agregar un municipio
@municipios_bp.route('/', methods=['POST'])
def agregar_municipio():
    data = request.get_json()
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute(
            "INSERT INTO Municipios (nombre, poblacion_total, hombres, edad_promedio, ingreso_promedio, temperatura_media, id_departamento) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s)",
            (data['nombre'], data['poblacion_total'], data['hombres'], data['edad_promedio'], data['ingreso_promedio'], data['temperatura_media'], data['id_departamento'])
        )
        conn.commit()
        return jsonify({'message': 'Municipio agregado exitosamente'}), 201
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

# Ruta para eliminar un municipio
@municipios_bp.route('/<int:id_municipio>', methods=['DELETE'])
def eliminar_municipio(id_municipio):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("DELETE FROM Municipios WHERE id_municipio = %s", (id_municipio,))
        conn.commit()
        return jsonify({'message': 'Municipio eliminado exitosamente'}), 200
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 400
    finally:
        conn.close()

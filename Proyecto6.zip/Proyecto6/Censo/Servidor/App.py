from flask import Flask, jsonify, request
from routes.municipios import municipios_bp
from routes.departamentos import departamentos_bp

app = Flask(__name__)

# Registrar las rutas de municipios y departamentos
app.register_blueprint(municipios_bp, url_prefix='/municipios')
app.register_blueprint(departamentos_bp, url_prefix='/departamentos')

if __name__ == '__main__':
    app.run(debug=True, port=5000)

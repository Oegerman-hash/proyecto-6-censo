from db_connection import get_db_connection

def agregar_municipio(data):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO Municipios (nombre, poblacion_total, hombres, edad_promedio, ingreso_promedio, temperatura_media, id_departamento) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s)",
        (data['nombre'], data['poblacion_total'], data['hombres'], data['edad_promedio'], data['ingreso_promedio'], data['temperatura_media'], data['id_departamento'])
    )
    conn.commit()
    conn.close()

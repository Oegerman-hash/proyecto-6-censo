from db_connection import get_db_connection

def obtener_departamento(id_departamento):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Departamentos WHERE id_departamento = %s", (id_departamento,))
    departamento = cursor.fetchone()
    conn.close()
    return departamento

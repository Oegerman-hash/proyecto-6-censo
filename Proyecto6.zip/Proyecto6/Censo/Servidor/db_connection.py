import pymysql

def get_db_connection():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="CensoMunicipal"
    )
if __name__ == '__main__':
    try:
        conn = get_db_connection()
        print("Conexión exitosa a la base de datos")
        conn.close()
    except Exception as e:
        print("Error al conectar a la base de datos:", e)